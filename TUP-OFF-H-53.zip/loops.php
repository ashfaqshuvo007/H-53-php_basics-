
<!DOCTYPE html>
<html lang="en">
    <head>
        <title>PHP :: BASICS</title>
        <meta charset="utf-8">
        <link rel="stylesheet" type="text/css" href="css/style.css">
    </head>
    <body>
        <div class="container">
            <header id="header">PHP :: For, foreach </header>
            <hr><hr>

            <?php
//            //For loop.
//            for($c=0;$c<5;$c++){
//                
//                echo "The value of C is: ".$c."<br>";
//            }
//           
//            //Foeach Loop
//            $arr = array("BMW","PORSHE","LAMBO");
////           
//            
//            
//            
//            foreach ($arr as $val) {
//                   echo "$val <br>";
//            }
//            
            
            
            
            //Do-while,While-do
//            $x=1;
//            do{
//               echo "$x<br>"; 
//               $x++;
//            }while($x<1);
//            

           
            
           
            
            ?>
        </div>
    </body>
</html>


