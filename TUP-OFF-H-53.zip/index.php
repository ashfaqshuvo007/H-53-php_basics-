<!DOCTYPE html>
<html lang="en">
    <head>
        <title>PHP :: BASICS</title>
        <meta charset="utf-8">
        <link rel="stylesheet" type="text/css" href="css/style.css">
    </head>
    <body>
        <div class="container">
            
            <hr>
            
            <header id="header"><?php echo "PHP :: BASICS"?></header>
            <hr>

            <?php
                
//              /*For loop */
  
            for($x=6;$x>=0;$x--){
              echo "The value now is: $x <br>";  
              
            }
//             
            
            
//            $cars = array("BMW","LAmbo","Toyota");
//            
//            foreach($cars as $v){
//                echo "Car name: $v <br>";
//            }
//            
          

            /* For each loop */

// $cars = array("BMW", "Lamborgini", "Porshe");
// foreach ($cars as $car) {
// 	echo "$car <br>";
// }
// $z = "Violet";
// function color() {
// 	global $z;
// 	$x = "RED";
// 	echo $x . "<br>";
// 	echo "From color : " . $z;
// 	echo "<br>";
// }
// function color2() {
// 	global $z;
// 	$y = "Blue";
// 	echo $y . "<br>";
// 	echo "From color 2 : " . $z;
// 	echo "<br>";
// }
// color();
// color2();*/
                /*TO print on the screen*/
//               $x = 5 ;
//                echo "<b style='color: red;'>the number is : </b>".$x;
                
                
            ?>



        </div>
    </body>
</html> 













