<?php


$t1 = $_GET['text1'];
$t2 = $_GET['text2'];
 
 echo $t1.$t2;